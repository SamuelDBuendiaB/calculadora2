package com.example.calculadora2;

public class accion {

    public String suma(String numero1, String numero2){
        int resultado = Integer.valueOf(String.valueOf(numero1)) + Integer.valueOf(String.valueOf(numero2));
        return String.valueOf(resultado);
    }

    public String resta(String numero1,String numero2){
        int resultado = Integer.valueOf(numero1) - Integer.valueOf(numero2);
        return String.valueOf(resultado);
    }

    public String multiplicacion(String numero1,String numero2){
        int resultado = Integer.valueOf(numero1) * Integer.valueOf(numero2);
        return String.valueOf(resultado);
    }

    public String divicion(String numero1,String numero2){
        int resultado = Integer.valueOf(numero1) / Integer.valueOf(numero2);
        return String.valueOf(resultado);
    }

    public String sequencia(){
        StringBuilder lista = new StringBuilder();
        int n = 14;
        int p = 0;
        int u = 1;

        for (int i = 1; i <= n; ++i) {
            lista.append(p).append(", ");
            int next = p + u;
            p = u;
            u = next;
        }
        return String.valueOf(lista.toString());
    }

    public String factorial(String numero1){
        int n = Integer.parseInt(numero1);
        int factorial = 1;

        for (int i = 1; i <= n; i++) {
            factorial *= i;
        }
        return String.valueOf(factorial);
    }
}
