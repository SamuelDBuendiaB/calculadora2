package com.example.calculadora2;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import junit.framework.TestCase;

import org.junit.Before;
import org.junit.Test;

public class accionTest extends TestCase {

    private  accion Oper;

    @Before
    public void setUp(){
        Oper = new accion();
    }
    @Test
    public void NotNUll(){
        assertNotNull(Oper);
    }

    public void testSuma() {assertEquals("7",Oper.suma("4","3"));}

    public void testResta() {assertEquals("1",Oper.resta("4","3"));
    }

    public void testMultiplicacion() {assertEquals("9",Oper.multiplicacion("3","3"));}

    public void testDivicion() {assertEquals("10",Oper.divicion("20","2"));}

    public void testSequencia() {
        String esperado = "0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, ";

        String resultado = Oper.sequencia();
        assertEquals(esperado, resultado);
    }
    public void testFactorial(){
        assertEquals("120",Oper.factorial("5"));

    }
}