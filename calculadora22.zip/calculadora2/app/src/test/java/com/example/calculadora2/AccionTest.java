package com.example.calculadora2;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import junit.framework.TestCase;

import org.junit.Before;
import org.junit.Test;

public class AccionTest extends TestCase {

    private Accion oper;

    @Before
    public void setUp(){
        oper = new Accion();
    }
    @Test
    public void NotNUll(){
        assertNotNull(oper);
    }

    public void testSuma() {assertEquals("7",oper.suma("4","3"));}

    public void testResta() {assertEquals("1",oper.resta("4","3"));
    }

    public void testMultiplicacion() {assertEquals("9",oper.multiplicacion("3","3"));}

    public void testDivicion() {assertEquals("10",oper.divicion("20","2"));}

    public void testSequencia() {
        String esperado = "0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, ";

        String resultado = oper.sequencia();
        assertEquals(esperado, resultado);
    }
    public void testFactorial(){
        assertEquals("120",oper.factorial("5"));

    }
}