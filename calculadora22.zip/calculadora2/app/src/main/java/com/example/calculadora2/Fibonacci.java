package com.example.calculadora2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Fibonacci extends AppCompatActivity {

    private TextView mostrar;
    private Button back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fibonacci);

        mostrar = findViewById(R.id.fibores);
        back = findViewById(R.id.volver);

        Intent intent = getIntent();
        if (intent !=null && intent.hasExtra("sequencia")){
            String answer = intent.getStringExtra("sequencia");
            mostrar.setText(answer);
        }else {
            mostrar.setText("No hay sequencia");
        }

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent inte = new Intent(Fibonacci.this,MainActivity.class);
                startActivity(inte);
            }
        });
    }
}